create table Returned_Book
(
    user_id       varchar(45) not null,
    book_id       int         not null,
    borrowed_date varchar(45) not null,
    returned_date varchar(45) not null,
    returned_id   int auto_increment
        primary key
);

INSERT INTO Library.Returned_Book (user_id, book_id, borrowed_date, returned_date, returned_id) VALUES ('userid12', 1, '4/30/2023 1:05:02 PM', '4/30/2023 1:23:32 PM', 1);
INSERT INTO Library.Returned_Book (user_id, book_id, borrowed_date, returned_date, returned_id) VALUES ('userid12', 2, '4/30/2023 1:05:42 PM', '4/30/2023 1:27:00 PM', 2);
INSERT INTO Library.Returned_Book (user_id, book_id, borrowed_date, returned_date, returned_id) VALUES ('userid12', 0, '4/30/2023 1:05:46 PM', '4/30/2023 1:28:46 PM', 3);
INSERT INTO Library.Returned_Book (user_id, book_id, borrowed_date, returned_date, returned_id) VALUES ('userid12', 1, '4/30/2023 2:24:57 PM', '4/30/2023 2:25:03 PM', 4);
