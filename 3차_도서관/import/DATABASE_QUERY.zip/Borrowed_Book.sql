create table Borrowed_Book
(
    user_id       varchar(45) not null,
    book_id       int         not null,
    borrowed_date varchar(45) not null,
    borrowed_id   int auto_increment
        primary key
);

